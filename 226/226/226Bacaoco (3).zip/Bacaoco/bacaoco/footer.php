<!DOCTYPE html>
<html>
<head>
	<title>My Website</title>
	<style>
		footer {
			background-color: #333;
			color:#77DD77;
			text-align: center;
			padding: 10px;
			position: absolute;
			bottom: 0;
			left: 0;
			right: 0;
		}
	</style>
</head>

	<footer>
		<p1>Niño Angelo D. Bacaoco BSIT-2</p1>
	</footer>
</body>
</html>